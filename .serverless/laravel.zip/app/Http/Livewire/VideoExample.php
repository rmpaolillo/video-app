<?php

namespace App\Http\Livewire;

use Livewire\Component;

class VideoExample extends Component
{
    public function render()
    {
        return view('livewire.video-example');
    }
}
