<?php return array (
  'counter' => 'App\\Http\\Livewire\\Counter',
  'course-lms.new-courses-logged-in' => 'App\\Http\\Livewire\\CourseLms\\NewCoursesLoggedIn',
  'course-video' => 'App\\Http\\Livewire\\CourseVideo',
  'row-example' => 'App\\Http\\Livewire\\RowExample',
  'video-example' => 'App\\Http\\Livewire\\VideoExample',
);