<!DOCTYPE html>
<html>
<body>

<button onclick="getCurTime()" type="button">Get current time position</button>
<button onclick="setCurTime()" type="button">Set time position to 5 seconds</button><br>

<video id="myVideo" width="640" height="480" controls>
  <source src="video/mov_bbb.mp4" type="video/mp4">
  {{-- <source src="video/mov_bbb.ogg" type="video/ogg"> --}}
  Your browser does not support HTML5 video.
</video>

<script>
var vid = document.getElementById("myVideo");

function getCurTime() {
  alert(vid.currentTime);
}

function setCurTime() {
  vid.currentTime=5;
}
</script>

<p>Video courtesy of <a href="https://www.bigbuckbunny.org/" target="_blank">Big Buck Bunny</a>.</p>

</body>
</html>
