<div>
    <div x-data="videos" x-on:visibilitychange.window="visibilityChange()"
        class="flex items-center justify-center w-full h-auto">
        <div class="flex items-center justify-center w-full h-auto my-10">
            <div class="w-full max-w-2xl">
                <h1 class="text-2xl font-bold text-center text-blue-800">
                    Frequenza Corso n. {{ $codice }}
                </h1>
                <h2 class="mt-2 text-3xl font-extrabold tracking-tight text-center text-purple-600">
                    {{ $title }}</h2>
                @foreach (json_decode($videos_json) as $key => $video)
                    @if ($key == $index)
                        <h3 class="mt-2 text-2xl font-extrabold tracking-tight text-center text-gray-500">
                            {{ Str::upper($video->titolo) }}</h3>
                    @endif
                @endforeach
                <div class="w-full p-2 mt-4 bg-green-200 rounded-lg">
                    <div class="flex flex-row items-center text-gray-700">
                        <svg class="w-6 h-6 mx-2" fill="none" stroke="currentColor" viewBox="0 0 24 24"
                            xmlns="http://www.w3.org/2000/svg">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                        </svg>
                        <p class="text-sm text-gray-700">Per rispondere <span class="font-bold">cliccare</span> sul
                            testo
                            della
                            risposta.</p>
                    </div>
                </div>
                {{-- nav videos blade --}}
                <nav aria-label="Progress" class="mt-4">
                    <ol role="list" class="flex items-center">
                        @foreach (json_decode($videos_json) as $key => $video)
                            <li class="relative @if ($key != count(json_decode($videos_json)) - 1) pr-8 sm:pr-20 @endif">
                                <!-- Upcoming Step -->
                                <div class="absolute inset-0 flex items-center" aria-hidden="true">
                                    <div
                                        class="h-0.5 w-full @if ($video->completato == 1) bg-violet-600 @else bg-gray-200 @endif">
                                    </div>
                                </div>
                                <div>
                                    @if ($video->completato == 1 && $key == $index)
                                        <a href="#" type="button" x-on:notify.window="isClickedGoTo = true"
                                            wire:click="goTo({{ $key }}, {{ $id_attendance }}, {{ $course_id }})"
                                            class="relative flex items-center justify-center w-8 h-8 bg-white border-2 rounded-full border-violet-600"
                                            aria-current="step">
                                            <span class="h-2.5 w-2.5 rounded-full bg-violet-600"
                                                aria-hidden="true"></span>
                                            <span class="sr-only">{{ $key + 1 }}</span>
                                        </a>
                                    @elseif($video->completato == 1 && $key != $index)
                                        <a href="#" type="button" x-on:notify.window="isClickedGoTo = true"
                                            wire:click="goTo({{ $key }}, {{ $id_attendance }}, {{ $course_id }})"
                                            class="relative flex items-center justify-center w-8 h-8 rounded-full bg-violet-600 hover:bg-violet-900">
                                            @if ($key != $index)
                                                <svg class="w-5 h-5 text-white" viewBox="0 0 20 20" fill="currentColor"
                                                    aria-hidden="true">
                                                    <path fill-rule="evenodd"
                                                        d="M16.704 4.153a.75.75 0 01.143 1.052l-8 10.5a.75.75 0 01-1.127.075l-4.5-4.5a.75.75 0 011.06-1.06l3.894 3.893 7.48-9.817a.75.75 0 011.05-.143z"
                                                        clip-rule="evenodd" />
                                                </svg>
                                            @endif
                                    @endif
                                    <span class="sr-only">{{ $key + 1 }}</span>
                                    </a>
                                </div>

                                @if ($video->completato != 1)
                                    <a href="#"
                                        class="relative flex items-center justify-center w-8 h-8 bg-white border-2 rounded-full group hover:border-gray-400 @if ($key == $index) border-violet-600 @else border-gray-300 @endif"
                                        aria-current="step">
                                        <span
                                            class="h-2.5 w-2.5 rounded-full @if ($key == $index) bg-violet-600 @else bg-transparent group-hover:bg-gray-300 @endif"
                                            aria-hidden="true"></span>
                                        <span class="sr-only">{{ $key + 1 }}</span>
                                    </a>
                                @endif
                            </li>
                        @endforeach
                    </ol>
                </nav>
                {{-- nav videos alpinejs --}}
                {{-- <nav aria-label="Progress" class="mt-4">
                    <ol role="list" class="flex items-center">
                        <template x-for="(video, key) in videos" :key>
                            <li class="relative" :class="key == count - 1 ? '' : 'pr-8 sm:pr-20'">
                                <!-- Upcoming Step -->
                                <div class="absolute inset-0 flex items-center" aria-hidden="true">
                                    <div class="h-0.5 w-full"
                                        :class="video.completed == 1 ? 'bg-violet-600' : 'bg-gray-200'"></div>
                                </div>
                                <template x-if="video.completed == 1 && key == index">
                                    <a href="#"
                                        class="relative flex items-center justify-center w-8 h-8 bg-white border-2 rounded-full border-violet-600"
                                        aria-current="step">
                                        <span class="h-2.5 w-2.5 rounded-full bg-violet-600" aria-hidden="true"></span>
                                        <span class="sr-only" x-text="key+1"></span>
                                    </a>
                                </template>
                                <template x-if="video.completed == 1 && key != index">
                                    <a href="#"
                                        class="relative flex items-center justify-center w-8 h-8 rounded-full bg-violet-600 hover:bg-violet-900">
                                        <template x-if="key != index">
                                            <svg class="w-5 h-5 text-white" viewBox="0 0 20 20" fill="currentColor"
                                                aria-hidden="true">
                                                <path fill-rule="evenodd"
                                                    d="M16.704 4.153a.75.75 0 01.143 1.052l-8 10.5a.75.75 0 01-1.127.075l-4.5-4.5a.75.75 0 011.06-1.06l3.894 3.893 7.48-9.817a.75.75 0 011.05-.143z"
                                                    clip-rule="evenodd" />
                                            </svg>
                                        </template>
                                </template>
                                <span class="sr-only" x-text="key+1"></span>
                                </a>
                                <template x-if="video.completed != 1">
                                    <a href="#"
                                        class="relative flex items-center justify-center w-8 h-8 bg-white border-2 rounded-full group hover:border-gray-400"
                                        :class="key == index ? 'border-violet-600' :
                                            'border-gray-300'"
                                        aria-current="step">
                                        <span class="h-2.5 w-2.5 rounded-full"
                                            :class="key == index ? 'bg-violet-600' :
                                                'bg-transparent group-hover:bg-gray-300'"
                                            aria-hidden="true"></span>
                                        <span class="sr-only" x-text="key+1"></span>
                                    </a>
                                </template>
                            </li>
                        </template>
                    </ol>
                </nav> --}}
                {{-- end nav videos alpinejs --}}

                {{-- videos blade --}}
                <div class="mt-6">
                    @foreach (json_decode($videos_json) as $key => $video)
                        <div class="w-full h-auto max-w-full video-container" x-ref="videoContainer"
                            x-on:fullscreenchange="">
                            <div class="playback-animation" x-ref="playbackAnimation">
                                <svg class="playback-icons">
                                    <use href="#play-icon"></use>
                                    <use href="#pause"></use>
                                </svg>
                            </div>
                            <div>
                            </div>
                            <div>
                                @if ($key == $index)
                                    <video controls x-ref="video" preload="metadata" x-init="initializeVideo()"
                                        x-on:click="togglePlay($event)" x-on:pause="togglePlay($event)"
                                        x-on:playing="togglePlay($event)" x-on:seeked="skipAhead($event)"
                                        x-on:timeupdate="updateTimeElapsed($event), updatePercentElapsed()">
                                        <source src="{{ $video->link }}" type="video/mp4">
                                    </video>
                                @endif
                            </div>
                            <div>
                                @if ($key == $index)
                                    <div class="inline-flex items-center justify-center overflow-hidden rounded-full">
                                        <svg class="w-20 h-20">
                                            <circle class="text-gray-300" stroke-width="5" stroke="currentColor"
                                                fill="transparent" r="30" cx="40" cy="40" />
                                            <circle x-show="!Number.isNaN(percent)" class="text-violet-600"
                                                stroke-width="5" :stroke-dasharray="circumference"
                                                :stroke-dashoffset="circumference - percent / 100 * circumference"
                                                stroke-linecap="round" stroke="currentColor" fill="transparent"
                                                r="30" cx="40" cy="40" />
                                        </svg>
                                        <span x-show="Number.isNaN(percent)" class="absolute text-xl text-violet-700"
                                            x-text="'0%'"></span>
                                        <span x-show="!Number.isNaN(percent)" class="absolute text-xl text-violet-700"
                                            x-effect="$el.textContent = Math.trunc((percentElapsed).toFixed(2)*100)+'%'"></span>
                                    </div>
                                    <div x-effect="$el.textContent=circumference"></div>
                                    <div x-effect="$el.textContent=circumference - percent / 100 * circumference">
                                    </div>
                                    <div x-show="!Number.isNaN(percent)" x-text="percent"></div>

                                    <div>tempoCompletato[{{ $key }}]: {{ $video->tempoCompletato }}</div>
                                    <div>durataVideo[{{ $key }}]: {{ $video->durataVideo }}</div>
                                    <div>videoCompletato[{{ $index }}]: {{ $video->completato }}</div>
                                    <div x-on:mouseenter="" x-on:mouseleave="" class="hidden video-controls"
                                        x-ref="videoControls">
                                        <div class="video-progress">
                                            <progress x-ref="progressBar" min="0" max="100"
                                                value="0"></progress>
                                            <input x-on:input="" x-on:mousemove="" class="seek" x-ref="seek"
                                                min="0" max="" type="range" step="1"
                                                value="0">
                                            <div class="seek-tooltip" id="seekTooltip">00:00</div>
                                        </div>

                                        <div class="bottom-controls">
                                            <div class="left-controls">
                                                <button x-ref="play" x-on:click="togglePlay">
                                                    <svg class="playback-icons">
                                                        <use href="#play-icon"></use>
                                                        <use href="#pause"></use>
                                                    </svg>
                                                </button>

                                                <div class="volume-controls">
                                                    <button x-on:click="" class="volume-button" id="volume-button"
                                                        x-ref="volumeButton">
                                                        <svg x-ref="volumeIcons" id="volume-icons">
                                                            <use x-ref="volumeMute" class="hidden"
                                                                href="#volume-mute">
                                                            </use>
                                                            <use x-ref="volumeLow" class="hidden" href="#volume-low">
                                                            </use>
                                                            <use x-ref="volumeHigh" href="#volume-high"></use>
                                                        </svg>
                                                    </button>

                                                    <input x-on:input="" class="volume" id="volume"
                                                        value="1" data-mute="0.5" type="range" max="1"
                                                        min="0" step="0.01" x-ref="volume">
                                                </div>

                                                <div class="time">
                                                    <time x-ref="timeElapsed">00:00</time>
                                                    <span> / </span>
                                                    <time x-ref="duration">00:00</time>
                                                </div>
                                            </div>

                                            <div class="right-controls">
                                                <button data-title="PIP (p)" class="pip-button" id="pip-button">
                                                    <svg>
                                                        <use href="#pip"></use>
                                                    </svg>
                                                </button>
                                                <button x-on:click="" class="fullscreen-button"
                                                    id="fullscreen-button" x-ref="fullscreenButton">
                                                    <svg>
                                                        <use href="#fullscreen"></use>
                                                        <use href="#fullscreen-exit" class="hidden"></use>
                                                    </svg>
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                @endif
                            </div>
                        </div>
                    @endforeach
                </div>
                {{-- end video  --}}

                {{-- videos alpinejs --}}
                {{-- <div class="mt-6">
                    <template x-for="(video, key) in videos" :key>
                        <div class="w-full h-auto max-w-full video-container" x-ref="videoContainer"
                            x-on:fullscreenchange="">
                            <div class="playback-animation" x-ref="playbackAnimation">
                                <svg class="playback-icons">
                                    <use href="#play-icon"></use>
                                    <use href="#pause"></use>
                                </svg>
                            </div>
                            <div>
                                <template x-if="key == index">
                                    <video controls x-ref="video" preload="metadata" x-on:click="togglePlay($event)"
                                        x-on:pause="togglePlay($event)" x-on:playing="togglePlay($event)"
                                        x-on:seeked="skipAhead($event)"
                                        x-on:timeupdate="updateTimeElapsed(), updatePercentElapsed()">
                                        <source src="{{ $video->link }}" type="video/mp4">
                                    </video>
                                </template>
                            </div>
                            <div>
                                <template x-if="key == index">
                                    <div class="inline-flex items-center justify-center overflow-hidden rounded-full">
                                        <svg class="w-20 h-20">
                                            <circle class="text-gray-300" stroke-width="5" stroke="currentColor"
                                                fill="transparent" r="30" cx="40" cy="40" />
                                            <circle class="text-violet-600" stroke-width="5"
                                                :stroke-dasharray="circumference"
                                                :stroke-dashoffset="circumference - percent / 100 * circumference"
                                                stroke-linecap="round" stroke="currentColor" fill="transparent"
                                                r="30" cx="40" cy="40" />
                                        </svg>
                                        <span class="absolute text-xl text-violet-700"
                                            x-effect="$el.textContent = Math.trunc((percentElapsed).toFixed(2)*100)+'%'"></span>
                                    </div>
                                    <div x-effect="$el.textContent=circumference"></div>
                                    <div x-effect="$el.textContent=circumference - percent / 100 * circumference">
                                    </div>

                                    <div>completedTime[{{ $key }}]: {{ $video->tempoCompletato }}</div>
                                    <div x-on:mouseenter="" x-on:mouseleave="" class="hidden video-controls"
                                        x-ref="videoControls">
                                        <div class="video-progress">
                                            <progress x-ref="progressBar" min="0" max="100"
                                                value="0"></progress>
                                            <input x-on:input="" x-on:mousemove="" class="seek" x-ref="seek"
                                                min="0" max="" type="range" step="1"
                                                value="0">
                                            <div class="seek-tooltip" id="seekTooltip">00:00</div>
                                        </div>

                                        <div class="bottom-controls">
                                            <div class="left-controls">
                                                <button x-ref="play" x-on:click="togglePlay">
                                                    <svg class="playback-icons">
                                                        <use href="#play-icon"></use>
                                                        <use href="#pause"></use>
                                                    </svg>
                                                </button>

                                                <div class="volume-controls">
                                                    <button x-on:click="" class="volume-button" id="volume-button"
                                                        x-ref="volumeButton">
                                                        <svg x-ref="volumeIcons" id="volume-icons">
                                                            <use x-ref="volumeMute" class="hidden"
                                                                href="#volume-mute">
                                                            </use>
                                                            <use x-ref="volumeLow" class="hidden" href="#volume-low">
                                                            </use>
                                                            <use x-ref="volumeHigh" href="#volume-high"></use>
                                                        </svg>
                                                    </button>

                                                    <input x-on:input="" class="volume" id="volume"
                                                        value="1" data-mute="0.5" type="range" max="1"
                                                        min="0" step="0.01" x-ref="volume">
                                                </div>

                                                <div class="time">
                                                    <time x-ref="timeElapsed">00:00</time>
                                                    <span> / </span>
                                                    <time x-ref="duration">00:00</time>
                                                </div>
                                            </div>

                                            <div class="right-controls">
                                                <button data-title="PIP (p)" class="pip-button" id="pip-button">
                                                    <svg>
                                                        <use href="#pip"></use>
                                                    </svg>
                                                </button>
                                                <button x-on:click="" class="fullscreen-button"
                                                    id="fullscreen-button" x-ref="fullscreenButton">
                                                    <svg>
                                                        <use href="#fullscreen"></use>
                                                        <use href="#fullscreen-exit" class="hidden"></use>
                                                    </svg>
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                </template>
                            </div>
                        </div>
                    </template>
                </div> --}}
                {{-- end video alpinejs  --}}
                $count: {{ count(json_decode($videos_json)) }}
                <br>
                $index: {{ $index }}
                <div class="flex justify-between">
                    <button type="button" wire:click="setCompleted({{ $index }}, {{ $id_attendance }})"
                        class="px-4 py-3 my-2 text-white bg-green-500 rounded-lg">SET COMPLETATO</button>
                    <button type="button" wire:click="setUncompleted({{ $index }}, {{ $id_attendance }})"
                        class="px-4 py-3 my-2 text-white bg-red-500 rounded-lg">SET NON COMPLETATO</button>
                </div>
                <div class="flex justify-between">
                    <button type="button"
                        wire:click="goToPrevious({{ $index }}, {{ $id_attendance }}, {{ $course_id }})"
                        x-on:notify.window="isClickedGoTo = true" x-on:click="isPlaying = false"
                        class="px-4 py-3 my-2 text-white bg-gray-500 rounded-lg">PRECEDENTE</button>
                    {{-- next button alpine js  --}}
                    {{-- <button type="button"
                        wire:click="goToNext({{ $index }}, {{ $id_attendance }}, {{ $course_id }})"
                        x-show="videos[index]['completed'] && index < count - 1"
                        class="px-4 py-3 my-2 text-white bg-gray-500 rounded-lg"
                        :class="(videos[index]['completed'] && !videos[index + 1]['completed']) ? 'animate-pulse' : ''">SUCCESSIVO</button> --}}
                    {{-- end button alpinejs --}}
                    {{-- next button blade  --}}
                    {{-- {{ dd(json_decode($videos_json)[0]->completato) }} --}}
                    <div>
                        @if (json_decode($videos_json)[$index]->completato && $index < count(json_decode($videos_json)) - 1)
                            <button type="button"
                                wire:click="goToNext({{ $index }}, {{ $id_attendance }}, {{ $course_id }}), updateTempVariable"
                                x-on:notify.window="isClickedGoTo = true" x-on:click="isPlaying = false"
                                class="px-4 py-3 my-2 text-white bg-gray-500 rounded-lg @if (json_decode($videos_json)[$index]->completato && !json_decode($videos_json)[$index + 1]->completato) animate-pulse @endif">SUCCESSIVO</button>
                        @endif
                    </div>
                    {{-- next button blade  --}}
                </div>
                @if ($completed)
                    <div class="flex justify-center">
                        <button class="px-4 py-3 my-2 text-white bg-yellow-600 rounded-lg">VAI AL TEST FINALE</button>
                    </div>
                @endif
                <br />
                <div>completedTimeTemp[{{ $index }}]: <span x-ref="elapsed" class="font-bold text-red-600"
                        x-effect="$el.textContent = completedTimeTemp"></span></div>
                index: {{ $index }}<br />
                is playing: <span class="font-bold text-red-600" x-effect="$el.textContent = isPlaying"></span><br />
                time elapsed: <span x-ref="elapsed" class="font-bold text-red-600"
                    x-effect="$el.textContent = timeElapsed"></span><br />
                time completed byref: <span class="font-bold text-red-600"
                    x-effect="$el.textContent = completedTime"></span><br />
                percent elapsed: <span class="font-bold text-red-600"
                    x-effect="$el.textContent = Math.trunc((percentElapsed).toFixed(2)*100)+'%'"></span><br />
                current time: <span class="font-bold text-red-600"
                    x-effect="$el.textContent = currentTime"></span><br />
                seek: <span class="font-bold text-red-600" x-effect="$el.textContent = seek"></span><br />
                progress bar: <span class="font-bold text-red-600"
                    x-effect="$el.textContent = progressBar"></span><br>
                videoDuration[{{ $index }}]: <span
                    class="font-bold text-red-600">{{ json_decode($videos_json)[$index]->durataVideo }}</span><br />
                tempoCompletato[{{ $index }}]: <span
                    class="font-bold text-red-600">{{ json_decode($videos_json)[$index]->tempoCompletato }}</span><br>
                <div x-text="index"></div>
                <div x-text="id_attendance"></div>
                <div x-text="currentTime"></div>
            </div>
        </div>
        {{-- start modal  --}}

        {{-- <template x-if="compliancePopup"> --}}
        @if ($compliancePopup)
            <div class="relative z-10" aria-labelledby="modal-title" role="dialog" aria-modal="true">
                <div class="fixed inset-0 transition-opacity bg-gray-500 bg-opacity-75"></div>
                <div class="fixed inset-0 z-10 overflow-y-auto">
                    <div class="flex items-end justify-center min-h-full p-4 text-center sm:items-center sm:p-0">
                        <div
                            class="relative px-4 pt-5 pb-4 overflow-hidden text-left transition-all transform bg-white rounded-lg shadow-xl sm:my-8 sm:w-full sm:max-w-lg sm:p-6">
                            <div>
                                <div
                                    class="flex items-center justify-center w-12 h-12 mx-auto bg-green-100 rounded-full">
                                    <svg class="w-6 h-6 text-green-600" fill="none" viewBox="0 0 24 24"
                                        stroke-width="1.5" stroke="currentColor" aria-hidden="true">
                                        <path stroke-linecap="round" stroke-linejoin="round"
                                            d="M4.5 12.75l6 6 9-13.5" />
                                    </svg>
                                </div>
                                <div class="mt-3 text-center sm:mt-5">
                                    <h3 class="text-base font-semibold leading-6 text-gray-900" id="modal-title">
                                        Controllo
                                        Conformità Frequenza Corso</h3>
                                    <div class="mt-2 space-y-2">
                                        <p class="text-sm text-gray-500">Stai vedendo questo "pop-up" ai fini della
                                            "compliance" che gli ordini professionali impongono per l'attestazione della
                                            frequenza a distanza dei corsi in modalità asincrona/P.O.D. (Play On Demand)
                                        </p>
                                        <p class="text-sm text-gray-500">Le interazioni con questa questo "pop up"
                                            verranno
                                            registrati sui nostri sistemi ai fini di controllo.</p>
                                        <p class="text-sm text-gray-500">Se non sei interessato ai "Crediti Formativi
                                            Professionali" puoi utilizzare il link del canale Youtube fornito in calce
                                            alla pagina.</p>
                                    </div>
                                </div>
                            </div>
                            <div class="mt-5 sm:mt-6 sm:grid sm:grid-flow-row-dense sm:grid-cols-2 sm:gap-3">
                                <button x-on:click="closeCompliacePopup()" type="button"
                                    class="inline-flex justify-center w-full px-3 py-2 text-sm font-semibold text-white bg-indigo-600 rounded-md shadow-sm hover:bg-indigo-500 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-600 sm:col-start-2">Ok
                                    Prosegui </button>
                                <button x-on:click="closeCompliacePopup()" type="button"
                                    class="inline-flex justify-center w-full px-3 py-2 mt-3 text-sm font-semibold text-gray-900 bg-white rounded-md shadow-sm ring-1 ring-inset ring-gray-300 hover:bg-gray-50 sm:col-start-1 sm:mt-0">Cancella</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            </template>
        @endif
        {{-- end modal  --}}

        {{-- wire loading --}}
        <div wire:loading wire:target="goTo, goToNext, goToPrevious, setCompleted, setUncompleted"
            class="relative z-10" aria-labelledby="modal-title" role="dialog" aria-modal="true">
            <div class="fixed inset-0 transition-opacity bg-gray-500 bg-opacity-75"></div>

            <div class="fixed inset-0 z-10 overflow-y-auto">
                <div class="flex items-end justify-center min-h-full p-4 text-center sm:items-center sm:p-0">

                    <div
                        class="relative px-4 pt-5 pb-4 overflow-hidden text-left transition-all transform bg-white rounded-lg shadow-xl sm:my-8 sm:w-full sm:max-w-sm sm:p-6">
                        <div>
                            <div class="flex items-center justify-center w-12 h-12 mx-auto bg-green-100 rounded-full">
                                <svg class="w-6 h-6 text-green-600" fill="none" viewBox="0 0 24 24"
                                    stroke-width="1.5" stroke="currentColor" aria-hidden="true">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="M4.5 12.75l6 6 9-13.5" />
                                </svg>
                            </div>
                            <div class="mt-3 text-center sm:mt-5">
                                <h3 class="text-base font-semibold leading-6 text-gray-900" id="modal-title">Attendere
                                    prego</h3>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        {{-- end wire loading --}}

        {{-- modal skipAhead --}}
        <div x-cloak x-show="alertSkipAhead" class="relative z-10" aria-labelledby="modal-title" role="dialog"
            aria-modal="true">
            <div class="fixed inset-0 transition-opacity bg-gray-500 bg-opacity-75"></div>
            <div class="fixed inset-0 z-10 overflow-y-auto">
                <div class="flex items-end justify-center min-h-full p-4 text-center sm:items-center sm:p-0">
                    <div x-on:click.outside="alertSkipAhead = false"
                        class="relative px-4 pt-5 pb-4 overflow-hidden text-left transition-all transform bg-white rounded-lg shadow-xl sm:my-8 sm:w-full sm:max-w-lg sm:p-6">
                        <div class="absolute top-0 right-0 hidden pt-4 pr-4 sm:block">
                            <button x-on:click="alertSkipAhead = false" type="button"
                                class="text-gray-400 bg-white rounded-md hover:text-gray-500 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2">
                                <span class="sr-only">Close</span>
                                <svg class="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke-width="1.5"
                                    stroke="currentColor" aria-hidden="true">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="M6 18L18 6M6 6l12 12" />
                                </svg>
                            </button>
                        </div>
                        <div class="sm:flex sm:items-start">
                            <div
                                class="flex items-center justify-center flex-shrink-0 w-12 h-12 mx-auto bg-red-100 rounded-full sm:mx-0 sm:h-10 sm:w-10">
                                <svg class="w-6 h-6 text-red-600" fill="none" viewBox="0 0 24 24"
                                    stroke-width="1.5" stroke="currentColor" aria-hidden="true">
                                    <path stroke-linecap="round" stroke-linejoin="round"
                                        d="M12 9v3.75m-9.303 3.376c-.866 1.5.217 3.374 1.948 3.374h14.71c1.73 0 2.813-1.874 1.948-3.374L13.949 3.378c-.866-1.5-3.032-1.5-3.898 0L2.697 16.126zM12 15.75h.007v.008H12v-.008z" />
                                </svg>
                            </div>
                            <div class="mt-3 text-center sm:ml-4 sm:mt-0 sm:text-left">
                                <h3 class="text-base font-semibold leading-6 text-gray-900" id="modal-title">
                                    Attenzione</h3>
                                <div class="mt-2">
                                    <p class="text-sm text-gray-500">Non si può andare avante e/o oltre la porzione di
                                        video che hai visualizzato.</p>
                                    <p class="text-sm text-gray-500">Questa operazione verrà registrata sui nostri
                                        sistemi.</p>
                                </div>
                            </div>
                        </div>
                        <div class="mt-5 sm:mt-4 sm:flex sm:flex-row-reverse">
                            <button x-on:click="alertSkipAhead = false" type="button"
                                class="inline-flex justify-center w-full px-3 py-2 text-sm font-semibold text-white bg-red-600 rounded-md shadow-sm hover:bg-red-500 sm:ml-3 sm:w-auto">Chiudi</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        {{-- emd modal --}}

        {{-- modal shkipBehind --}}
        <div x-cloak x-show="alertSkipBehind" class="relative z-10" aria-labelledby="modal-title" role="dialog"
            aria-modal="true">
            <div class="fixed inset-0 transition-opacity bg-gray-500 bg-opacity-75"></div>
            <div class="fixed inset-0 z-10 overflow-y-auto">
                <div class="flex items-end justify-center min-h-full p-4 text-center sm:items-center sm:p-0">
                    <div
                        class="relative px-4 pt-5 pb-4 overflow-hidden text-left transition-all transform bg-white rounded-lg shadow-xl sm:my-8 sm:w-full sm:max-w-lg sm:p-6">
                        <div class="sm:flex sm:items-start">
                            <div
                                class="flex items-center justify-center flex-shrink-0 w-12 h-12 mx-auto bg-red-100 rounded-full sm:mx-0 sm:h-10 sm:w-10">
                                <svg class="w-6 h-6 text-red-600" fill="none" viewBox="0 0 24 24"
                                    stroke-width="1.5" stroke="currentColor" aria-hidden="true">
                                    <path stroke-linecap="round" stroke-linejoin="round"
                                        d="M12 9v3.75m-9.303 3.376c-.866 1.5.217 3.374 1.948 3.374h14.71c1.73 0 2.813-1.874 1.948-3.374L13.949 3.378c-.866-1.5-3.032-1.5-3.898 0L2.697 16.126zM12 15.75h.007v.008H12v-.008z" />
                                </svg>
                            </div>
                            <div class="mt-3 text-center sm:ml-4 sm:mt-0 sm:text-left">
                                <h3 class="text-base font-semibold leading-6 text-gray-900" id="modal-title">
                                    Attenzione</h3>
                                <div class="mt-2">
                                    <p class="text-sm text-gray-500">Sei sicuro di volenr andare indietro?
                                        Andando indietro perderai i progressi fatti. Solo quando avrai terminato
                                        l'intero video/modulo potrai andare avanti e/o indietro liberamente.</p>
                                </div>
                            </div>
                        </div>
                        <div class="mt-5 sm:mt-4 sm:flex sm:flex-row-reverse">
                            <button x-on:click="alertSkipBehind = false" type="button"
                                class="inline-flex justify-center w-full px-3 py-2 text-sm font-semibold text-white bg-red-600 rounded-md shadow-sm hover:bg-red-500 sm:ml-3 sm:w-auto">Procedo
                                Comunque</button>
                            <button x-on:click="alertSkipBehind = false, setCurTime(completedTimeTemp)" type="button"
                                class="inline-flex justify-center w-full px-3 py-2 mt-3 text-sm font-semibold text-gray-900 bg-white rounded-md shadow-sm ring-1 ring-inset ring-gray-300 hover:bg-gray-50 sm:mt-0 sm:w-auto">Cancella
                                Azione</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        {{-- end modal skipBehind --}}
    </div>
    <script>
        document.addEventListener('alpine:init', () => {
            Alpine.data('videos', function() {
                window.localStorage.removeItem('_x_id_attendance')
                window.localStorage.removeItem('_x_codice')
                window.localStorage.removeItem('_x_course_id')
                window.localStorage.removeItem('_x_course_uuid')
                window.localStorage.removeItem('_x_index')
                window.localStorage.removeItem('_x_videos')
                window.localStorage.removeItem('_x_completed')
                window.localStorage.removeItem('_x_dateTimeCompleted')
                window.localStorage.removeItem('_x_count')
                window.localStorage.removeItem('_x_compliancePopup')
                window.setInterval(() => {
                    test = false;
                    if (test) {
                        let istante = new Date()
                        window.localStorage.setItem('_x_compliancePopup', true)
                        @this.openCompliance()
                    } else {
                        return
                    }
                }, Math.round(Math.random() * (20000 - 5000)) + 5000)
                return {
                    id_attendance: @entangle('id_attendance'),
                    codice: @entangle('codice'),
                    course_id: @entangle('course_id'),
                    course_uuid: @entangle('course_uuid'),
                    index: @entangle('index'),
                    videos: @entangle('videos_json'),
                    dateTimeCompleted: @entangle('dateTimeCompleted'),
                    count: this.$persist({{ count(json_decode($videos_json)) }}),
                    compliancePopup: @entangle('compliancePopup'),
                    isClickedGoTo: false,
                    isPlaying: false,
                    videoDuration: 0,
                    completedTime: 0,
                    videoDurationTemp: 0,
                    completedTimeTemp: 0,
                    timeElapsed: 0,
                    currentTime: 0,
                    percentElapsed: 0,
                    seek: 0,
                    progressBar: 0,
                    completed: @entangle('completed'),
                    circumference: 30 * 2 * Math.PI,
                    percent: 0,
                    alertSkipAhead: false,
                    alertSkipBehind: false,
                    visibilityChange() {
                        if ((document.visibilityState !== "visible") && (this.completed == 0))  {
                            this.$refs.video.pause()
                            this.isPlaying = false
                        } else {
                            //this.$refs.video.play()
                            //this.isPlaying = true
                        }
                    },
                    setUncompleted(index, prop, value) {
                        if (index == this.count - 1) {
                            this.completed = 0
                        }
                        this.videos[index][prop] = value
                        @this.update(this.id_attendance, this.codice, this.course_id, this
                            .course_uuid, this
                            .index, this.videos, this.completed, this.dateTimeCompleted)
                    },
                    closeCompliacePopup() {
                        this.compliancePopup = false
                        @this.closeCompliance()
                    },
                    initializeVideo() {
                        (JSON.parse(this.videos)).forEach((detail, index) => {
                            if (this.index == index) {
                                this.videoDurationTemp = detail.durataVideo
                                this.completedTimeTemp = detail.tempoCompletato
                                this.setCurTime(this.completedTimeTemp)
                            }
                        })
                    },
                    formatTime(timeInSeconds) {},
                    togglePlay(event) {
                        if (event.type === "pause") {
                            if (this.currentTime > this.currentTimeTemp) {
                                this.currentTimeTemp = this.currentTime
                            }
                            this.isPlaying = false
                        } else if (event.type === "playing") {
                            this.isPlaying = true
                        }
                    },
                    skipAhead(event) {
                        if (event.type === 'seeked') {
                            if (this.currentTime > this.completedTimeTemp) {
                                this.$refs.video.pause()
                                this.setCurTime(this.completedTimeTemp)
                                this.alertSkipAhead = true
                            } else if (this.currentTime < this.completedTimeTemp) {
                                this.alertSkipBehind = true
                            }
                        }
                    },
                    updateTempVariable() {},
                    updateTimeElapsed() {
                        if ((JSON.parse(this.videos)[this.index]['completato'])) {
                            return
                        }
                        const time = this.formatTime(Math.round(this.$refs.video.currentTime))
                        this.currentTime = this.$refs.video.currentTime
                        if (!this.isClickedGoTo) {
                            @this.updateCompletedTime(this.index, this.id_attendance, this
                                .currentTime)
                        }
                        if (this.$refs.video.currentTime > this.completedTime) {
                            this.completedTime = this.$refs.video.currentTime
                        }
                        this.$refs.timeElapsed.innerText = `${time.minutes}:${time.seconds}`
                        this.$refs.timeElapsed.setAttribute('datetime',
                            `${time.minutes}m ${time.seconds}s`)
                        this.timeElapsed = `${time.minutes}:${time.seconds}`

                        this.isClickedGoTo = false
                        // return `${time.minutes}:${time.seconds}`
                    },
                    formatTime(timeInSeconds) {
                        const result = new Date(timeInSeconds * 1000).toISOString().substr(11, 8)
                        return {
                            minutes: result.substr(3, 2),
                            seconds: result.substr(6, 2)
                        }
                    },
                    updatePercentElapsed() {
                        const videoDuration = Math.round(this.$refs.video.duration)
                        const time = Math.round(this.$refs.video.currentTime)
                        this.percentElapsed = time / videoDuration
                        this.percent = Math.trunc((this.percentElapsed).toFixed(2) * 100)
                        if (this.percentElapsed > 0.99) {
                            @this.setCompleted(this.index, this.id_attendance)
                        }
                        return time / videoDuration
                    },
                    setCurTime(arg) {
                        this.currentTime = arg
                        this.$refs.video.currentTime = this.currentTime
                    },
                }
            })
        })
    </script>
</div>
